package com.example.visprogweek5realtask.soal2.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.visprogweek5realtask.soal2.model.QuizQuestion
import com.example.visprogweek5realtask.soal2.model.UserAnswer

enum class QuizState {
    START, PLAYING, RESULT
}

class QuizViewModel : ViewModel() {


    private val questionBank = listOf(
        QuizQuestion(
            id = 1,
            questionText = "Ibu Kota Di Indonesia?",
            options = listOf("Surabaya", "Bandung", "Jakarta", "Medan"),
            correctAnswer = "Jakarta"
        ),
        QuizQuestion(
            id = 2,
            questionText = "Apakah Mata Kuliah VP susah?",
            options = listOf("Sangat Susah", "Sulit", "Lumayan", "Sangat Mudah"),
            correctAnswer = "Sangat Mudah"
        ),
        QuizQuestion(
            id = 3,
            questionText = "Natal dirayakan pada bulan?",
            options = listOf("Agustus", "Oktober", "Desember", "Januari"),
            correctAnswer = "Desember"
        ),
        QuizQuestion(
            id = 4,
            questionText = "Ada berapa hari dalam seminggu?",
            options = listOf("5", "6", "7", "11"),
            correctAnswer = "7"
        ),
        QuizQuestion(
            id = 5,
            questionText = "Mata Kuliah VP pakai apa?",
            options = listOf("Word", "Excel", "Android Studio", "Photoshop"),
            correctAnswer = "Android Studio"
        )
    )


    var quizState by mutableStateOf(QuizState.START)
        private set

    var questionCountInput by mutableStateOf("")
        private set

    var countError by mutableStateOf<String?>(null)
        private set

    private val _activeQuestions = mutableStateListOf<QuizQuestion>()
    val activeQuestions: List<QuizQuestion> get() = _activeQuestions

    var currentQuestionIndex by mutableIntStateOf(0)
        private set

    var selectedOption by mutableStateOf<String?>(null)
        private set

    private val _userAnswers = mutableStateListOf<UserAnswer>()
    val userAnswers: List<UserAnswer> get() = _userAnswers

    fun onQuestionCountInputChanged(input: String) {
        questionCountInput = input
        if (countError != null) countError = null
    }

    fun startQuiz() {
        val count = questionCountInput.toIntOrNull()
        if (count == null || count < 1 || count > questionBank.size) {
            countError = "Maximum is ${questionBank.size} questions"
            return
        }


        _activeQuestions.clear()
        _activeQuestions.addAll(questionBank.shuffled().take(count))


        _userAnswers.clear()
        currentQuestionIndex = 0
        selectedOption = null
        countError = null
        quizState = QuizState.PLAYING
    }

    fun selectOption(option: String) {
        selectedOption = option
    }

    fun nextQuestion() {
        val currentQuestion = _activeQuestions.getOrNull(currentQuestionIndex) ?: return
        val chosenOption = selectedOption ?: return

        _userAnswers.add(UserAnswer(question = currentQuestion, selectedAnswer = chosenOption))
        selectedOption = null

        if (currentQuestionIndex + 1 < _activeQuestions.size) {
            currentQuestionIndex++
        } else {
            quizState = QuizState.RESULT
        }
    }

    fun restartQuiz() {
        quizState = QuizState.START
        questionCountInput = ""
        selectedOption = null
        _userAnswers.clear()
        _activeQuestions.clear()
    }

    fun getScore(): Int {
        return _userAnswers.count { it.selectedAnswer == it.question.correctAnswer }
    }

    fun getWrongAnswers(): List<UserAnswer> {
        return _userAnswers.filter { it.selectedAnswer != it.question.correctAnswer }
    }
}