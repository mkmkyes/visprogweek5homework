package com.example.visprogweek5realtask.soal1.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.visprogweek5realtask.soal1.model.Expense
import java.text.NumberFormat
import java.util.Locale

class ExpenseViewModel : ViewModel() {


    private val _expenses = mutableStateListOf(
        Expense(name = "Makan Nasi", amount = 90000),
        Expense(name = "Investasi", amount = 10000000),
        Expense(name = "Kopi", amount = 18000)
    )
    val expenses: List<Expense> get() = _expenses


    var expenseNameInput by mutableStateOf("")
        private set

    var amountInput by mutableStateOf("")
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var editingExpense by mutableStateOf<Expense?>(null)
        private set

    fun onExpenseNameChange(newName: String) {
        expenseNameInput = newName
    }

    fun onAmountChange(newAmount: String) {
        amountInput = newAmount
        if (errorMessage != null) {
            errorMessage = null
        }
    }

    fun addExpense() {
        val amount = amountInput.toIntOrNull()

        if (expenseNameInput.isBlank()) {
            errorMessage = "Expense name cannot be empty"
            return
        }

        if (amount == null || amount <= 0) {
            errorMessage = "Amount must be greater than 0"
            return
        }

        _expenses.add(0, Expense(name = expenseNameInput.trim(), amount = amount))

        expenseNameInput = ""
        amountInput = ""
        errorMessage = null
    }

    fun deleteExpense(expense: Expense) {
        _expenses.remove(expense)
    }

    fun startEditing(expense: Expense) {
        editingExpense = expense
    }

    fun cancelEditing() {
        editingExpense = null
    }

    fun saveEditedExpense(updatedName: String, updatedAmount: Int) {
        editingExpense?.let { current ->
            val index = _expenses.indexOfFirst { it.id == current.id }
            if (index != -1) {
                _expenses[index] = current.copy(name = updatedName, amount = updatedAmount)
            }
        }
        editingExpense = null
    }

    fun getTotalExpense(): Int {
        return _expenses.sumOf { it.amount }
    }

    fun formatRupiah(amount: Int): String {
        val localeID = Locale.Builder().setLanguage("in").setRegion("ID").build()
        val format = NumberFormat.getCurrencyInstance(localeID)
        format.maximumFractionDigits = 0
        return format.format(amount).replace("Rp", "Rp ")
    }
}