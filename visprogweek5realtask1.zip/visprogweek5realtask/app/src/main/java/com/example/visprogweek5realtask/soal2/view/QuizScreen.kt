package com.example.visprogweek5realtask.soal2.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.visprogweek5realtask.soal2.viewmodel.QuizState
import com.example.visprogweek5realtask.soal2.viewmodel.QuizViewModel

@Composable
fun QuizScreen(viewModel: QuizViewModel = remember { QuizViewModel() }) {
    val state = viewModel.quizState

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)),
        contentAlignment = Alignment.Center
    ) {
        when (state) {
            QuizState.START -> StartQuizView(viewModel)
            QuizState.PLAYING -> PlayingQuizView(viewModel)
            QuizState.RESULT -> ResultQuizView(viewModel)
        }
    }
}

@Composable
fun StartQuizView(viewModel: QuizViewModel) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Mini Quiz",
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF334155)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "How many questions do you want? (1 - 5)",
            fontSize = 13.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = viewModel.questionCountInput,
            onValueChange = { viewModel.onQuestionCountInputChanged(it) },
            label = { Text("Number of questions", fontSize = 12.sp) },
            singleLine = true,
            isError = viewModel.countError != null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedBorderColor = if (viewModel.countError != null) Color.Red else Color(0xFF475569),
                unfocusedBorderColor = if (viewModel.countError != null) Color.Red else Color(0xFFCBD5E1)
            ),
            modifier = Modifier.fillMaxWidth()
        )

        if (viewModel.countError != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = viewModel.countError!!,
                color = Color.Red,
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { viewModel.startQuiz() },
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFE2E8F0),
                contentColor = Color.Gray
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(text = "Start Quiz", fontSize = 14.sp)
        }
    }
}

@Composable
fun PlayingQuizView(viewModel: QuizViewModel) {
    val questions = viewModel.activeQuestions
    val currentIndex = viewModel.currentQuestionIndex
    val currentQuestion = questions.getOrNull(currentIndex) ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Question ${currentIndex + 1}",
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF334155)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = currentQuestion.questionText,
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))


        currentQuestion.options.forEach { option ->
            val isSelected = viewModel.selectedOption == option

            Button(
                onClick = { viewModel.selectOption(option) },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSelected) Color(0xFF4F5D86) else Color(0xFFE2E8F0),
                    contentColor = if (isSelected) Color.White else Color(0xFF334155)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Text(text = option, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }

            Spacer(modifier = Modifier.height(10.dp))
        }

        Spacer(modifier = Modifier.height(20.dp))


        val isNextEnabled = viewModel.selectedOption != null

        Button(
            onClick = { viewModel.nextQuestion() },
            enabled = isNextEnabled,
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF4F5D86),
                contentColor = Color.White,
                disabledContainerColor = Color(0xFFE2E8F0),
                disabledContentColor = Color.LightGray
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
        ) {
            Text(text = "Next", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ResultQuizView(viewModel: QuizViewModel) {
    val score = viewModel.getScore()
    val total = viewModel.activeQuestions.size
    val wrongAnswers = viewModel.getWrongAnswers()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Quiz Finished!",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Your Score: $score / $total",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(24.dp))

        if (wrongAnswers.isEmpty()) {
            Text(
                text = "Perfect! No wrong answers.",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF4F5D86),
                modifier = Modifier.padding(vertical = 20.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(wrongAnswers) { item ->
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Q${item.question.id}: ${item.question.questionText}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF334155)
                        )
                        Text(
                            text = "Your Answer: ${item.selectedAnswer}",
                            fontSize = 12.sp,
                            color = Color(0xFFDC2626)
                        )
                        Text(
                            text = "Correct Answer: ${item.question.correctAnswer}",
                            fontSize = 12.sp,
                            color = Color(0xFF2563EB)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.restartQuiz() },
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF4F5D86),
                contentColor = Color.White
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(text = "Restart Quiz", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun QuizScreenPreview() {
    MaterialTheme {
        QuizScreen()
    }
}