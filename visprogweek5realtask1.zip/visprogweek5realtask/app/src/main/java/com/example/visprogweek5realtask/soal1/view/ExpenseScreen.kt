package com.example.visprogweek5realtask.soal1.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.visprogweek5realtask.soal1.model.Expense
import com.example.visprogweek5realtask.soal1.viewmodel.ExpenseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseScreen(viewModel: ExpenseViewModel = viewModel()) {
    val expenses = viewModel.expenses
    val totalExpense = viewModel.getTotalExpense()
    val errorMessage = viewModel.errorMessage
    val editingExpense = viewModel.editingExpense

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(24.dp))


            Text(
                text = "Expenses",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B)
            )

            Spacer(modifier = Modifier.height(2.dp))


            Text(
                text = "Total Expense : ${viewModel.formatRupiah(totalExpense)}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(16.dp))


            OutlinedTextField(
                value = viewModel.expenseNameInput,
                onValueChange = { viewModel.onExpenseNameChange(it) },
                label = { Text("Expense Name", fontSize = 12.sp) },
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = Color(0xFF94A3B8),
                    unfocusedBorderColor = Color(0xFFCBD5E1)
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))


            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = viewModel.amountInput,
                    onValueChange = { viewModel.onAmountChange(it) },
                    label = { Text("Amount of Expense", fontSize = 12.sp) },
                    singleLine = true,
                    isError = errorMessage != null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = if (errorMessage != null) Color.Red else Color(0xFF94A3B8),
                        unfocusedBorderColor = if (errorMessage != null) Color.Red else Color(0xFFCBD5E1)
                    ),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(10.dp))


                IconButton(
                    onClick = { viewModel.addExpense() },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Expense",
                        tint = Color(0xFF475569)
                    )
                }
            }


            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))


            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(expenses, key = { it.id }) { expense ->
                    ExpenseCardItem(
                        expense = expense,
                        formattedAmount = viewModel.formatRupiah(expense.amount),
                        onDelete = { viewModel.deleteExpense(expense) },
                        onEdit = { viewModel.startEditing(expense) }
                    )
                }
            }
        }


        FloatingActionButton(
            onClick = { },
            containerColor = Color.White,
            contentColor = Color.Black,
            shape = CircleShape,
            elevation = FloatingActionButtonDefaults.elevation(4.dp),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
                .size(44.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Menu,
                contentDescription = "Menu",
                modifier = Modifier.size(20.dp)
            )
        }
    }


    if (editingExpense != null) {
        EditExpenseDialog(
            expense = editingExpense,
            onDismiss = { viewModel.cancelEditing() },
            onConfirm = { newName, newAmount ->
                viewModel.saveEditedExpense(newName, newAmount)
            }
        )
    }
}

@Composable
fun ExpenseCardItem(
    expense: Expense,
    formattedAmount: String,
    onDelete: () -> Unit,
    onEdit: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0E7FF)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Name : ${expense.name}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E1B4B)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = formattedAmount,
                    fontSize = 12.sp,
                    color = Color(0xFF4338CA)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit",
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(18.dp)
                    )
                }


                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EditExpenseDialog(
    expense: Expense,
    onDismiss: () -> Unit,
    onConfirm: (String, Int) -> Unit
) {
    var name by remember { mutableStateOf(expense.name) }
    var amountText by remember { mutableStateOf(expense.amount.toString()) }
    var dialogError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Expense", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Expense Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                if (dialogError != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = dialogError!!, color = Color.Red, fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val parsedAmount = amountText.toIntOrNull()
                if (name.isBlank()) {
                    dialogError = "Name cannot be empty"
                } else if (parsedAmount == null || parsedAmount <= 0) {
                    dialogError = "Amount must be greater than 0"
                } else {
                    onConfirm(name.trim(), parsedAmount)
                }
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ExpenseScreenPreview() {
    MaterialTheme {
        ExpenseScreen()
    }
}