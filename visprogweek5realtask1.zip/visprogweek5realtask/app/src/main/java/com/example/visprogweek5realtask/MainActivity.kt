package com.example.visprogweek5realtask

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.example.visprogweek5realtask.soal1.view.ExpenseScreen
import com.example.visprogweek5realtask.soal2.view.QuizScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                //ExpenseScreen() //soal1
                QuizScreen() //soal2
            }
        }
    }
}