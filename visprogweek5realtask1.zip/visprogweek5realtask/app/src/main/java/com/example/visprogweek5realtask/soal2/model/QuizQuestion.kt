package com.example.visprogweek5realtask.soal2.model

data class QuizQuestion(
    val id: Int,
    val questionText: String,
    val options: List<String>,
    val correctAnswer: String
)

data class UserAnswer(
    val question: QuizQuestion,
    val selectedAnswer: String
)